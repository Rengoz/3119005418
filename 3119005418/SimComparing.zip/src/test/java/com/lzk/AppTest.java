package com.lzk;

import static org.junit.Assert.assertTrue;

import com.hankcs.hanlp.HanLP;
import com.lzk.function.hamming.utils.HammingUtils;
import com.lzk.function.io.utils.TxtIO;
import com.lzk.function.simhash.utils.SimHashUtils;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
//    @Test
//    public void methodReadTxtText() throws Exception{
//        System.out.println(TxtIO.txtRead().size());
//        System.out.println(TxtIO.txtRead("orig.txt"));
//        System.out.println(TxtIO.txtRead().get(0));
//    }
//    @Test
//    public void testtxt(){
//        String s1 = TxtIO.txtRead("orig.txt");
//        String s2 = TxtIO.txtRead("orig_0.8_add.txt");
//        System.out.println(SimHashUtils.getHash(s1));
//        System.out.println(SimHashUtils.getHash(s2));
//        System.out.println(HammingUtils.getSimilarity(s1,s2));
//    }
@Test
    public void hanLpTest() throws IOException {
    File file = new File("C:\\Users\\22154\\Desktop\\wenben1\\orig.txt");
    String str = null;
    String strLine = "";
    InputStream in = new FileInputStream(file);
    InputStreamReader reader = new InputStreamReader(in);
    BufferedReader bufferedReader = new BufferedReader(reader);
    while ((str = bufferedReader.readLine())!=null){
        strLine += str;
    }
    List<String> strings = HanLP.extractKeyword(strLine,strLine.length());
    int i = 0;
    for (String s:strings
         ) {
        System.out.print(strings.get(i++)+",");
    }

    }
    @Test
    public void testBundle() {


    }
}



